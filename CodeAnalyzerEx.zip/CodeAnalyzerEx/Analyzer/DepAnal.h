#pragma once
///////////////////////////////////////////////////////////////////
// DepenAnal.h: Creates Dependency Information by Scanning AST   //
// ver 1.0                                                       //
// Application: Type Based Dependency Analysis, Spring 2017      //
// Platform:    LenovoFlex4, Win 10, Visual Studio 2015          //
// Author:      Chandra Harsha Jupalli, OOD Project2             //
//              cjupalli@syr.edu                                 //
//Reference:    Dr.Fawcett, Syracuse University                  //
///////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Uses Abstract Syntax Tree to scan dependency information
* It helps executive with accessing medium level details of creating a Dependency Table and TypeTable
* It helps executive access strong Components information
*
* Required Files:
* ---------------
*   - Action and Rules.h,TypeAnalysis.h,DependencyAnalysis.h,FileSystem.h
*
*
* Public Interface
* --------------------
*  using CodeAnalysis                     //Namespace used to check coding standards of the project
*  doTypeAnal()                           //Implements type analysis by scanning the AST 
*  DependencyTable()                      //Traveres Directories in current path specified and invokes dependency table 
*  DFS()                                  //scans Abstract Syntax tree 
* Build Process:
* --------------
*   devenv CodeAnalyzerEx.sln /debug rebuild
*
* Maintenance History:
* --------------------
* Ver 1.0 : 11 March 2017
* - first release
*
*/

#include "../Parser/ActionsAndRules.h"
#include "TypeAnalysis.h"
#include <iostream>
#include "../DependencyAnalysis/DependencyAnalysis.h"
#include "../StrongComponents/StrongComponent.h"
#include "../FileSystem/FileSystem.h"
#include <set>

using namespace strongComp;
using Keys = std::vector<std::string>;


#pragma warning (disable : 4101)  // disable warning re unused variable x, below

namespace CodeAnalysis
{
	class TypeAnal
	{
	public:
		using SPtr = std::shared_ptr<ASTNode*>;

		TypeAnal();
		void doTypeAnal();
		void dependencyTable(int argc, char* argv[]);
		void ASTDisp();
	private:
		void DFS(ASTNode* pNode);
		AbstrSynTree& ASTref_;
		ScopeStack<ASTNode*> scopeStack_;
		Scanner::Toker& toker_;
		TypeTable TT;
		NoSqlDb <std::string> DBnew;
		std::set<std::string> myvector;
		DependencyAnalysis  dep;
		FileSystem::Directory directory;
		FileSystem::Path  path;
		Graph graph;

	};

	inline TypeAnal::TypeAnal() :
		ASTref_(Repository::getInstance()->AST()),
		scopeStack_(Repository::getInstance()->scopeStack()),
		toker_(*(Repository::getInstance()->Toker()))
	{
		//directory()
		std::function<void()> test = [] { int x; };  // This is here to test detection of lambdas.
	}                                              // It doesn't do anything useful for dep anal.

	inline bool doDisplay(ASTNode* pNode)
	{
		static std::string toDisplay[] = {
		  "function", "lambda", "class", "struct", "enum", "alias", "typedef"
		};
		for (std::string type : toDisplay)
		{
			if (pNode->type_ == type)
				return true;
		}
		return false;
	}
	inline void TypeAnal::DFS(ASTNode* pNode)
	{
		static std::string path = "";
		if (pNode->path_ != path){
			std::cout << "\n    -- " << pNode->path_ << "\\" << pNode->package_;
			path = pNode->path_;
		}
		if (doDisplay(pNode)) {
			std::cout << "\n  " << pNode->name_;
			std::cout << ", " << pNode->type_;
			//std::cout << " ," << pNode->parentType_;
		}

		if ((pNode->type_ == "struct") || (pNode->type_ == "class") || (pNode->type_ == "interface")) {
			std::vector<std::pair<std::string, std::string>> KeyPair;
			KeyPair.push_back(std::make_pair(pNode->type_, pNode->package_));
			TT.getTypeTable().insert(std::make_pair(pNode->name_, KeyPair));
		}

		for (auto pChild : pNode->children_)
			DFS(pChild);
	}

	inline void TypeAnal::doTypeAnal()
	{
		std::cout << "\n  starting type analysis:\n";
		std::cout << "\n  scanning AST and displaying important things:";
		std::cout << "\n -----------------------------------------------";
		ASTNode* pRoot = ASTref_.root();
		DFS(pRoot);

		std::cout << "\n";
		std::cout << "\n Requirements 2 and 3 can be verified from the code\n\n Requirement of displaying type table\n\n";

		for (auto iteration = TT.getTypeTable().begin(); iteration != TT.getTypeTable().end(); iteration++) {
			std::cout << std::setw(30) << iteration->first << std::left << "\t\t";
			std::vector<std::pair<std::string, std::string>> KeyPair = iteration->second;
			for (auto temp : KeyPair) {
				std::cout << std::setw(30) << temp.first << std::left << " \t\t" << temp.second << "\n";
			}
		}

		//std::cout << "\n\n **************************printing  Dependency Table***************************\n ";
		//dep.DependencyAnalysistable(TT);


	}

	inline void TypeAnal::dependencyTable(int argc, char* argv[]) {
		std::vector<std::string> filecontainer;
		std::vector<std::string> currentFiles;
		string dirpath_ = argv[1];
		std::vector<std::string> currentDirectories = directory.getDirectories(dirpath_);
		for (size_t i = 0; i < currentDirectories.size(); i++) {
			std::cout << currentDirectories[i]<<"\n";
		}
		for (size_t i = 0; i < currentDirectories.size(); i++) {
			std::string appendpath = dirpath_ + "/" + currentDirectories[i];
			std::vector<std::string> temporaryFiles = directory.getFiles(appendpath);
			for (size_t k = 0; k < temporaryFiles.size(); k++) {
				currentFiles.push_back(dirpath_ + "/" + currentDirectories[i] + "/" + temporaryFiles[k]);
			}
		}

		for (size_t temp = 0; temp < currentFiles.size(); temp++) {
			if ((path.getExt(currentFiles[temp]) == "h") || (path.getExt(currentFiles[temp]) == "cpp"))
				filecontainer.push_back(currentFiles[temp]);
		}
		//print the result 
		std::cout << "\n\n **************************printing  Dependency Table***************************\n ";
		std::cout << "\n\n  List of files checked into dependency table check\n\n";
		for (size_t t = 0; t < filecontainer.size(); t++) {
			std::cout << filecontainer[t] << "\n";
		}
		std::cout << "\n\n********************************Dependency Relationships******************** \n\n";
		for (auto t : filecontainer) {
			std::string refTTString = t;
			dep.DependencyAnalysistable(TT, refTTString);
		}

		std::cout << "\n\ncreating file with name XMLDependencyAnalysisResults for storing dependency analysis information in to Project Solution Debug Folder ";
		std::string s = toXml(dep.getDataBase());
		std::cout << s;
		std::ofstream myXmlFile;//create file
		myXmlFile.open("XmlDependencyAnalysis.xml");
		myXmlFile << s;
		myXmlFile.close();
	}

	inline void TypeAnal::ASTDisp() {
		DBnew = dep.getDataBase();
		std::unordered_map<int, std::string> setVal;
		std::unordered_map<std::string, int> graph_map;
		graph.setgraphsize((int)DBnew.keys().size());
		int k = 0;

		for (std::string key : DBnew.keys())
		{
			graph_map[key] = k;
			setVal[k] = key;
			k++;
		}
		for (std::string key : DBnew.keys())
		{
			Element<StrData> dependencies = DBnew.value(key);
			std::vector<std::string> myVec = dependencies.children.getValue();
			for (std::string child : myVec)
			{
				if (!(key == child))
				{
					graph.addEdge(graph_map[key], graph_map[child]);
				}
			}
		}
		graph.setFileGraphPath(setVal);

		cout << "\n\n*******Showing Strong Components files*************\n";
		graph.SCC();
		//graph.displayStrongComponentDB();
		std::cout << "\n\nCould not store Strong Components values in DataBase due to linker error\n Feel free to verify StrongComponenet.h to check Tarzan Algorithm \n\n";
		std::cout << "\nRequirement 8 of processing comamnd line by parsing directories and patterns can be verified from TypeAnal::DependenyTable() in DepAnal.h \n";
		std::cout << "\n\n Requirement 9 of The automated test suite of requirements is done\n\n";
	}

}
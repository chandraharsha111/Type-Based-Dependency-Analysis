//////////////////////////////////////////////////////////////////////////
// StrongComponents.h: create a directed graph using tarzan's algorithm //
// ver 1.0                                                              //
// Application: Type Based Dependency Analysis, Spring 2017             //
// Platform:    LenovoFlex4, Win 10, Visual Studio 2015                 //
// Author:      Chandra Harsha Jupalli, OOD Project2                    //
//              cjupalli@syr.edu                                        //
//Reference:    Dr.Fawcett, Syracuse University                         //
//////////////////////////////////////////////////////////////////////////



/*
* Package Operations:
* -------------------
* This package finds the strong component graph using tarzan's algorithm.
* It creates a create a directed graph and look for any loops between nodes or vertices
* In case any loops are found amoung Vertices of the graph then they are listed as strong components
*
*
*
* Public Interface
* -------------------------------
* void addEdge(int v, int w);																		    // function to add an edge to graph
* void setGraphSize(int a);																		        // to set the graph size
* void setFileGraphPath(std::unordered_map<int, std::string> setVal) { get_MapVal = setVal; }			//to get the files from key
* void SCC();																						    // prints strongly connected components
*
* Required Files:
* ---------------
*  NoSqlDb.h,Persist.h,TyeAnalysis.h,DependencyAnalysis.h,DepAnal.h

* Build Process:
* --------------
*   devenv CodeAnalyzerEx.sln /debug rebuild
*
* Maintenance History:
* --------------------
* Ver 1.0 : 11 March 2017
* - first release
*
*/


#pragma once
#include <string>
#include<iostream>
#include <list>
#include <stack>
#include <algorithm>
#include<unordered_map>
#include "../HelpSession/NoSqlDb/NoSqlDb.h"
#include "../HelpSession/DbToXml/persist.cpp"
using namespace std;
using Key = std::string;
using StrData = std::string;
using Keys = std::vector<std::string>;

namespace strongComp {
	class Graph
	{
	int V;                                                                                    // No. of vertices
	list<int> *adj;                                                                           // A dynamic array of adjacency lists
	std::unordered_map<int, std::string> get_MapVal;
	void SCCUtil(int u, int disc[], int low[],stack<int> *st, bool stackMember[]);            // A Recursive DFS based function used by SCC()
	NoSqlDb<StrData> dbStrong;
		
	public:
		Graph();                                                                              // Constructor
		void addEdge(int v, int w);                                                           // function to add an edge to graph
		void setgraphsize(int a);
		void setFileGraphPath(std::unordered_map<int, std::string> setVal) { get_MapVal = setVal; }
		void displayStrongComponentDB();                                                       // prints strongly connected components
		void SCC();                                                                            //void strongcomponents();
	};

	inline Graph::Graph(){
	}

	inline void Graph::addEdge(int v, int w){
		adj[v].push_back(w);
	}

	inline void Graph::setgraphsize(int a){
		this->V = a;
		adj = new list<int>[a];
	}

	// A recursive function that finds and prints strongly connected components using DFS traversal
	inline void Graph::SCCUtil(int u, int disc[], int low[], stack<int> *st,bool stackMember[]){
		static int time = 0;                                                 // Initialize discovery time and low value
		disc[u] = low[u] = ++time;
		st->push(u);
		stackMember[u] = true;
                                                       
        list <string> strongComponents;                                       // Go through all vertices adjacent to this
		list<int>::iterator i;
		for (i = adj[u].begin(); i != adj[u].end(); ++i){
			int v = *i;                                                        
			if (disc[v] == -1){
				SCCUtil(v, disc, low, st, stackMember);
				low[u] = min(low[u], low[v]);
			}
			else if (stackMember[v] == true)
				low[u] = min(low[u], disc[v]);
		}
		int w = 0;                                                              // To store stack extracted vertices
		if (low[u] == disc[u]){
			while (st->top() != u){
				w = (int)st->top();
				std::cout << get_MapVal[w] << " --> ";
				stackMember[w] = false;
				st->pop();
			}
			w = (int)st->top();
			std::cout << get_MapVal[w] << "  " << "\n";
			stackMember[w] = false;
			st->pop();
		}
	}

	inline void Graph::displayStrongComponentDB()
	{

		std::string name;
		Element<std::string> elem;
		std::cout << "-------------------- Displaying Strong Componenents in NoSql Database -------------------------- \n";
		for (auto it : get_MapVal) {
			name = "Strong Component";
			elem.name = name;
			elem.children.getValue().push_back(it.second + "\n");
		}
		dbStrong.save(elem.name, elem);
		Keys keys = dbStrong.keys();
		for (Key itm : keys) {
			std::cout << " " << itm;
			std::cout << " " << dbStrong.value(itm).show();
		}
		std::cout << "-------------------- Persisting Strong Componenents of NoSql Database in Xml File -------------------------- \n";
		std::string s = toXml(dbStrong);
		std::cout << s;
	}

	// The function to do DFS traversal. It uses SCCUtil()
	inline void Graph::SCC()
	{
		int *disc = new int[V];
		int *low = new int[V];
		bool *stackMember = new bool[V];
		stack<int> *st = new stack<int>();

		// Initialize disc and low, and stackMember arrays
		for (int i = 0; i < V; i++){
			disc[i] = -1;
			low[i] = -1;
			stackMember[i] = false;
		}

		// Call the recursive helper function to find strongly connected components in DFS tree with vertex 'i'
		for (int i = 0; i < V; i++)
			if (disc[i] == -1)
				SCCUtil(i, disc, low, st, stackMember);
	}

}
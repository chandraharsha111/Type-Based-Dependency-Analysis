////////////////////////////////////////////////////////////////////////////////////
// StrongComponenets.cpp: Helps to find strong components using Tarzan algorithm  //
// ver 1.0                                                                        //
// Application: Type Based Dependency Analysis, Spring 2017                       //
// Platform:    LenovoFlex4, Win 10, Visual Studio 2015                           //
// Author:      Chandra Harsha Jupalli, OOD Project2                              //
//              cjupalli@syr.edu                                                  //
////////////////////////////////////////////////////////////////////////////////////


#include <string>
#include<iostream>
#include <list>
#include <stack>
#include <algorithm>
#include<unordered_map>
#include "../HelpSession/NoSqlDb/NoSqlDb.h"
#include "StrongComponent.h"
using namespace std;
using Key = std::string;
using StrData = std::string;
using Keys = std::vector<std::string>;

#ifdef Strong_Components
inline Graph::Graph() {
}

inline void Graph::addEdge(int v, int w) {
	adj[v].push_back(w);
}

inline void Graph::setgraphsize(int a) {
	this->V = a;
	adj = new list<int>[a];
}

// A recursive function that finds and prints strongly connected components using DFS traversal
inline void Graph::SCCUtil(int u, int disc[], int low[], stack<int> *st, bool stackMember[]) {
	static int time = 0;                                                 // Initialize discovery time and low value
	disc[u] = low[u] = ++time;
	st->push(u);
	stackMember[u] = true;

	list <string> strongComponents;                                       // Go through all vertices adjacent to this
	list<int>::iterator i;
	for (i = adj[u].begin(); i != adj[u].end(); ++i) {
		int v = *i;
		if (disc[v] == -1) {
			SCCUtil(v, disc, low, st, stackMember);
			low[u] = min(low[u], low[v]);
		}
		else if (stackMember[v] == true)
			low[u] = min(low[u], disc[v]);
	}
	int w = 0;                                                              // To store stack extracted vertices
	if (low[u] == disc[u]) {
		while (st->top() != u) {
			w = (int)st->top();
			std::cout << get_MapVal[w] << "  ";
			stackMember[w] = false;
			st->pop();
		}
		w = (int)st->top();
		std::cout << get_MapVal[w] << "  " << "\n";
		stackMember[w] = false;
		st->pop();
	}
}

int main() {
	Graph g;
	g.addEdge(1, 2);
	g.addEdge(2, 4);
	g.addEdge(4, 1);
}

#endif 

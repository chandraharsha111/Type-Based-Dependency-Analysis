// Utilities.cpp

#include "Utilities.h"

int main()
{
  Title("this is a lead title");
  putLine();
  subTitle("this is a sub-title");
  putLines(4);
}
#pragma once

#include "FileB.h"
#include "FileC.h"
#include <iostream>


struct  x
{

};
void abc() {}
namespace TestA {
	void def() {}
	class FileA {
	public:
		void showA();
	private:
		FileB fileB;
		TestC::FileA a;
	};

	void FileA::showA() {
		std::cout << "\nInside Show Function of FileA\n";
		fileB.showB();
	}
}
